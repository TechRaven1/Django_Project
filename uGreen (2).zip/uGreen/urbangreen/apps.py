from django.apps import AppConfig


class UrbangreenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'urbangreen'
